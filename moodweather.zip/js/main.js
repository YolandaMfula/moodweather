// Auto location
window.onload = () => {
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(async (position) => {
      const { latitude, longitude } = position.coords;
      await getWeatherByCoords(latitude, longitude);
    });
  }
};

async function getWeatherByCoords(lat, lon) {
  const apiKey = "027f6f520dcd27140fb325cb16e9a045";
  const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    displayWeather(data);
  } catch (error) {
    console.error("Location error:", error.message);
  }
}

async function getWeather() {
  const city = document.getElementById("cityInput").value;
  const apiKey = "027f6f520dcd27140fb325cb16e9a045";

  if (!city) {
    alert("Please enter a city name.");
    return;
  }

  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    displayWeather(data);
  } catch (error) {
    alert("Error fetching weather: " + error.message);
  }
}

function displayWeather(data) {
  const iconCode = data.weather[0].icon;
  const iconUrl = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;

  const weatherInfo = `
    <p><strong>City:</strong> ${data.name}</p>
    <p><strong>Temperature:</strong> ${data.main.temp}°C</p>
    <p><strong>Condition:</strong> ${data.weather[0].description}</p>
    <p><strong>Humidity:</strong> ${data.main.humidity}%</p>
    <img src="${iconUrl}" alt="${data.weather[0].description}" />
  `;

  document.getElementById("weatherResult").innerHTML = weatherInfo;
}

const moodLabels = [];
const moodData = [];

const moodChart = new Chart(document.getElementById("moodChart"), {
  type: "bar",
  data: {
    labels: moodLabels,
    datasets: [{
      label: "Mood Log",
      backgroundColor: "#fff",
      borderColor: "#5a4fcf",
      data: moodData,
    }]
  },
  options: {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
});

function logMood() {
  const mood = document.getElementById("moodInput").value;
  if (!mood) {
    alert("Please enter your mood.");
    return;
  }

  moodLabels.push(new Date().toLocaleTimeString());
  moodData.push(1);
  moodChart.update();

  const moodEntry = document.createElement("p");
  moodEntry.textContent = `Mood logged: ${mood}`;
  document.getElementById("moodTrends").appendChild(moodEntry);

  document.getElementById("moodInput").value = "";
}
